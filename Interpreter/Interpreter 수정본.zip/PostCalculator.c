#include <string.h>
#include <ctype.h>
#include "ListBaseStack.h"

int RPNExp(char exp[])
{
	Stack stack;
	int expLen = strlen(exp);
	char tok;
	int op1, op2;

	Init(&stack);

	for (int i = 0; i < expLen; i++)
	{
		tok = exp[i];

		if (isdigit(tok))
		{
			int temp = 0;

			//���ڷ� ǥ���� ���� �ڸ� ���ڸ� .�� ��Ÿ�� ������ ���� ������ ��ȯ
			while (1)
			{

				temp += exp[i++] - '0';

				if (exp[i] == '.')
				{
					break;
				}
				
				temp *= 10;
			}

			Push(&stack, temp);
		}
		else
		{
			op2 = Pop(&stack);
			op1 = Pop(&stack);

			switch (tok)
			{
			case '+':
				Push(&stack, op1 + op2);
				break;
			case '-':
				Push(&stack, op1 - op2);
				break;
			case '*':
				Push(&stack, op1 * op2);
				break;
			case '/':
				Push(&stack, op1 / op2);
				break;
			}
		}
	}
	return Pop(&stack);
}