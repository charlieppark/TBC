#ifndef __INFIX_CALCULATOR__
#define __INFIX_CALCULATOR__

int InfixExp(char exp[]);

#endif