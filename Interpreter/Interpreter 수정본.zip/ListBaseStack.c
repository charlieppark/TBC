#include <stdio.h>
#include <stdlib.h>
#include "ListBaseStack.h"

//���� �ʱ�ȭ
void Init(Stack* pstack)
{
	pstack->head = NULL;
}

//������ ����ִ��� Ȯ��
int IsEmpty(Stack* pstack)
{
	if (pstack->head == NULL)
		return TRUE;
	else
		return FALSE;
}

//���� Push
void Push(Stack* pstack, Data data)
{
	Node* newNode = (Node*)malloc(sizeof(Node));

	newNode->data = data;
	newNode->next = pstack->head;

	pstack->head = newNode;
}

//���� Pop
Data Pop(Stack* pstack)
{
	Data rdata;
	Node* rnode;

	if (IsEmpty(pstack))
	{
		printf("Stack Memory Error!");
		exit(-1);
	}

	rdata = pstack->head->data;
	rnode = pstack->head;

	pstack->head = pstack->head->next;
	free(rnode);

	return rdata;
}

//���� Peek
Data Peek(Stack* pstack)
{
	if (IsEmpty(pstack))
	{
		printf("Stack Memory Error!");
		exit(-1);
	}

	return pstack->head->data;
}