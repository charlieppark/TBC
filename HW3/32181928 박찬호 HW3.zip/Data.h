#ifndef __DATA_H__
#define __DATA_H__

#include <stdio.h>

typedef int DATA;

#endif
