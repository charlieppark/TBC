#include "BFS.h"

typedef struct _queue
{
	NODE* node[12];
	int frontIdx;
	int rearIdx;
}QUEUE; // ������ queue����ü

bool BFS(NODE* root, int* searchNum, DATA* result)
{
	NODE* current = root;
	QUEUE queue = { .frontIdx = 0, .rearIdx = 0 };
	queue.node[queue.rearIdx] = root; //root enqueue

	int tempNum = *searchNum;

	while (current != NULL)
	{
		if (current->left != NULL)
		{
			//left subtree enqueue
			queue.rearIdx++;
			queue.node[queue.rearIdx] = current->left;
		}
		if (current->right != NULL)
		{
			//right subtree enqueue
			queue.rearIdx++;
			queue.node[queue.rearIdx] = current->right;
		}

		if (queue.frontIdx <= queue.rearIdx) // queue�� ������� �ʴٸ�
		{
			tempNum--;
			if (tempNum == 0)
			{ // Ž�� Ƚ���� �´� ������
				*result = current->data;
				return true;
			}
			//dequeue
			queue.frontIdx++;
			current = queue.node[queue.frontIdx];
		}
		else
			current = NULL;
	}
	return false; // Ž�� ����
}
