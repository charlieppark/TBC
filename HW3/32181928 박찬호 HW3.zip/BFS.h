#ifndef __BFS_H__
#define __BFS_H__

#include <stdbool.h>
#include "Data.h"
#include "BST.h"

bool BFS(NODE* root, int* searchNum, DATA* result);

#endif

