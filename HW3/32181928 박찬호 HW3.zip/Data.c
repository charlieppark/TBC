#include "Data.h"

void print(DATA d)
{
	printf("%d\n", d);
}

/*void fprint(FILE* fp_w, DATA d)
{
	fprintf(fp_w, "%d\n", d);
}*/
